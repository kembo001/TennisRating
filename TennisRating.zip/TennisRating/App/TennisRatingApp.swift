import SwiftUI

@main
struct TennisRatingApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
